Newsvendor: python_SGD_NV_code

1. create_config.py creates config files: config.pkl for standard setting and config_mismatch.pkl for model mis-specification.
In create_config, please specify problem parameters. Scenarios are hard-coded for K=5, 10, and 15.
2. Run train_approx_oracle_data.py to generate the (p,w) data set for oracle approximation. Generated dataset will be saved in oracle_data/pw_dataset.
3. Run train_approx_oracle.py to get the approximated oracle. The ourput approximated oracle is saved in oracle_data. Available oracles used in the experiment in under the folder oracle_data/nn
Approximated oracle is stored in 'oracle_pickle_dir'
4. Folder tools includes the implementation of the ICEO and benchmark methods.

5. Run nv_iceo_test.py for the iceo methods, run nv_iceo_test_entropy for the two step ETO methods with cross-entropy loss, run nv_iceo_test_baseline_only for other benchmarks. Outputs are saved under the folder iceo_results.

6. plot_iceo_results.ipynb for the plots.

Network flow: python_SGD_Net_code

Similar to NV
