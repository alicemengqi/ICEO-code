import pickle
import numpy as np
problem_params = {
    #'train_sample_size': 50,
    'test_sample_size': 500, # 10000
    'n_trails': 25,
    'dim_sol': 4,
    'dim_features': 5,
    'dim_scenario': 5,
    'scenario_list': np.array([[1.411441, 16.519779, 0.548652, 3.598200],
  [2.919887, 2.408818, 2.081370, 2.163493],
  [0.123442, 8.085430, 0.276777, 3.432811],
  [8.932937, 0.769055, 1.413136, 0.100291],
  [4.889119, 2.813464, 1.819007, 7.213648],
  [10.608435, 0.143297, 11.535804, 0.494919],
  [0.004825, 0.010799, 0.184079, 0.018554],
  [0.493836, 11.108500, 3.756536, 6.436532],
  [0.647171, 8.852180, 6.165669, 2.576713],
  [5.981172, 1.493690, 7.191768, 1.763514],
  [8.081012, 13.955062, 0.332960, 7.415544],
  [3.645159, 6.734041, 6.581146, 3.503203],
  [9.534242, 1.280481, 6.823592, 3.215876],
  [4.553855, 5.306134, 2.320332, 9.995780],
  [0.338866, 5.585264, 1.949093, 6.221872]
  ]),
    'c_list' : np.array([1, 3, 2, 2.5]),
    'flow': 10,
    'big_m': 1e5,
    'setting': 'network flow',
    'regularization_rho': 1e-6,
    'oracle_kernel': 'nn', #'polynomial',
    #'oracle_sample_size': 1000,
    'x_range': 5, # used to be 5
    'test_batch': 1000,
    'epoch_num': 5000,
 #   'pred_model': 'two_layers', #'linear', #'two_layers',
    #'baseline': None, #['saa', 'knn', 'kernel', 'forest'], ## run 'cvxpy' separately
    'knn_grid': [ 5,10,25],
    'kernel_grid': [20, 100, 500],
    'oracle_pickle_dir': 'PATH/oracle_data/nn/2023-06-11_22-24-39' #2023-05-14_23-51-35' #2023-05-15_17-02-46   #
    #'deg_data': 1,
    #'deg_data': 1,
    # 'train_grid': [100, 300, 500, 700,900 ],
    # 'deg_grid': [0]
}

problem_params['data_generation_model'] = 'two_layer'
problem_params['pred_model'] = 'two_layers'
problem_params['train_grid'] = [100, 300, 500, 700]
problem_params['deg_grid'] = [1]
with open('config.pkl', 'wb') as file:
    pickle.dump(problem_params, file)


problem_params['data_generation_model'] = 'model mis-specification-deg'
problem_params['pred_model'] = 'linear'
problem_params['train_grid'] =  [100] #[100, 300, 500, 700]
problem_params['deg_grid'] = [1, 2, 3, 4, 5]
with open('config_mismatch.pkl', 'wb') as file:
    pickle.dump(problem_params, file)

    