import pickle
import numpy as np
problem_params = {
    'test_sample_size': 500, 
    'n_trails': 25, 
    'dim_sol': 2,
    'dim_features': 6,
    'dim_scenario': 10,
    'scenario_list':np.array([[ 15.08,  76.15],
       [ 47.24,   6.48],
       [  4.12,  56.63],
       [ 21.65,  37.  ],
       [  8.69,  66.52],
       [  8.99,  84.36],
       [  2.15,  23.51],
       [  7.86,  82.53],
       [  1.77,  77.95],
       [ 57.28,  17.01]#,
    #    [  5.63, 108.73],
    #    [ 40.19,  46.2 ],
    #    [ 82.42,   5.15],
    #    [ 19.82,  71.71],
    #    [ 24.31,  42.97]
       ]),
    
     
    'h_list': [1,1.3],
    'b_list': [9,8],
    'setting': 'newsvendor',
    'regularization_rho': 0.01,
    'budget': 50,
    'oracle_kernel': 'nn', 
    #'oracle_sample_size': 1000,
    'x_range': 5,
    'test_batch': 1000,
    'epoch_num': 5000,
 #   'pred_model': 'two_layers', #'linear', #'two_layers',
    #'baseline': None, #['saa', 'knn', 'kernel', 'forest'], ## run 'cvxpy' separately
    'knn_grid': [ 5,10,25],
    'kernel_grid': [5,10, 80, 100],
    'entropy_loss': False,
    'oracle_pickle_dir': 'PATH/oracle_data/nn/2023-05-09_15-11-43' 
}

problem_params['data_generation_model'] = 'two_layer'
problem_params['pred_model'] = 'two_layers'
problem_params['train_grid'] = [100, 300, 500, 700]
problem_params['deg_grid'] = [1]
with open('config.pkl', 'wb') as file:
    pickle.dump(problem_params, file)



problem_params['data_generation_model'] = 'model mis-specification-deg'
problem_params['pred_model'] = 'linear'
problem_params['train_grid'] =  [500] #[100, 300, 500, 700]
problem_params['deg_grid'] = [ 2, 4, 5]
with open('config_mismatch.pkl', 'wb') as file:
    pickle.dump(problem_params, file)